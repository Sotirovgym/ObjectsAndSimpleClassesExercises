﻿using System;
using System.Collections.Generic;
using System.Linq;

class Cat
{
    public string Name { get; set; }

    public int Age { get; set; }

    public int IntelligenceQuotient { get; set; }

    public void ProduceSound()
    {
        Console.WriteLine("I'm an Aristocat, and I will now produce an aristocratic sound! Myau Myau.");
    }
}

