﻿using System;
using System.Collections.Generic;
using System.Linq;

class BankAccount
{
    public string Name { get; set; }

    public string Bank { get; set; }

    public decimal Balance { get; set; }
}

