﻿using System;
using System.Collections.Generic;
using System.Linq;

class Website
{
    public string Host { get; set; }

    public string Domain { get; set; }

    public List<string> Queries { get; set; }
}

